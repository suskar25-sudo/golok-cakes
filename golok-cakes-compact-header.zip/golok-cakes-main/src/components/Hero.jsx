import React from 'react';
import heroImage from '../assets/goloka-hero-bakery.png';

const Hero = ({ onNavigate }) => {
  return (
    <section id="home" className="goloka-hero" aria-label="Golok Cakes celebration cakes">
      <img
        src={heroImage}
        alt="Golok Cakes handcrafted celebration cake with cupcakes, macarons and desserts"
        className="goloka-hero__image"
      />
      <div className="goloka-hero__wash" aria-hidden="true" />

      <div className="goloka-hero__inner">
        <div className="goloka-hero__copy">
          <p className="goloka-hero__eyebrow">BAKED WITH LOVE &amp; DEVOTION</p>
          <h1 className="goloka-hero__title">
            Handcrafted with
            <span>Devotion:</span>
            <span>Cakes for Every</span>
            <span>Celebration</span>
          </h1>

          <p className="goloka-hero__description">
            Golok Cakes brings handcrafted eggless cakes, desserts and treats for every celebration — freshly made with love and carefully customized for your special moments.
          </p>

          <div className="goloka-hero__actions">
            <button
              type="button"
              onClick={() => onNavigate?.('products')}
              className="goloka-hero__button goloka-hero__button--primary"
            >
              EXPLORE CAKES
            </button>
            <button
              type="button"
              onClick={() => onNavigate?.('contact')}
              className="goloka-hero__button goloka-hero__button--secondary"
            >
              CUSTOMIZE YOUR CAKE
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
