import React from 'react';
import { Card, CardContent } from './ui/card';
import { Star } from 'lucide-react';
import { testimonials } from '../mock';

const Testimonials = () => (
  <section className="py-16 md:py-24 bg-[#f6e9d8] border-y border-[#eadcc8]">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center max-w-3xl mx-auto mb-12 md:mb-16">
        <p className="text-[11px] tracking-[.22em] uppercase font-semibold text-[#aa7b49] mb-3">Sweet words</p>
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold text-[#2d2118] mb-4" style={{fontFamily:'Georgia, Times New Roman, serif'}}>
          What Our <span className="text-[#8b542d]">Customers Say</span>
        </h2>
        <div className="w-20 h-[2px] bg-[#c89d6f] mx-auto mb-6"></div>
        <p className="text-lg md:text-xl text-[#65584d]">A few kind words from our happy customers.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
        {testimonials.map((testimonial) => (
          <Card key={testimonial.id} className="border border-[#eadbc7] shadow-[0_12px_34px_rgba(86,58,32,.07)] hover:shadow-[0_16px_42px_rgba(86,58,32,.10)] transition-all duration-300 bg-[#fff9f0]">
            <CardContent className="p-6 md:p-8">
              <div className="flex space-x-1 mb-4">
                {[...Array(testimonial.rating)].map((_, index) => <Star key={index} className="w-5 h-5 fill-[#d39b3f] text-[#d39b3f]" />)}
              </div>
              <p className="text-[#5e5146] mb-6 leading-relaxed italic">“{testimonial.text}”</p>
              <div className="flex items-center justify-between pt-4 border-t border-[#eee1cf]">
                <div><p className="font-bold text-[#34271e]">{testimonial.name}</p><p className="text-sm text-[#78695c]">{testimonial.occasion}</p></div>
                <div className="w-12 h-12 bg-[#ead5bd] rounded-full flex items-center justify-center text-[#83532f] font-bold text-lg">{testimonial.name.charAt(0)}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  </section>
);

export default Testimonials;
