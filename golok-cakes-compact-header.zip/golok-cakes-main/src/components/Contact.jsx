import React from 'react';
import { CakeSlice, Check, Sparkles } from 'lucide-react';
import cakeBanner from '../assets/goloka-hero-bakery.png';
import logo from '../assets/logo.png';

export default function Contact() {
  const googleFormUrl = 'https://forms.gle/4Bom5wbDG5dx1Bp6A';
  const googleFormEmbedUrl = 'https://docs.google.com/forms/d/e/1FAIpQLScQ0_bX9EWZtfJehaUjaWAZfIW0NsnNtTTyYcO86y9YXuuMPA/viewform?embedded=true';

  return (
    <section id="contact" className="relative overflow-hidden bg-[#f7eddf] py-16 md:py-24 border-t border-[#e3d2bd]">
      <div className="absolute -top-24 -left-24 h-72 w-72 rounded-full bg-white/50 blur-3xl" />
      <div className="absolute -bottom-24 -right-24 h-80 w-80 rounded-full bg-[#e7d2b9]/50 blur-3xl" />

      <div className="relative max-w-[1180px] mx-auto px-5 sm:px-8 lg:px-12">
        <div className="text-center max-w-3xl mx-auto mb-10 md:mb-12">
          <p className="text-[11px] font-semibold tracking-[.23em] uppercase text-[#9d744c] mb-3">Made especially for you</p>
          <h2 className="text-[38px] md:text-[50px] leading-tight text-[#2d2118]" style={{ fontFamily: 'Georgia, Times New Roman, serif' }}>
            Customize Your Cake
          </h2>
          <div className="w-20 h-[2px] bg-[#bf956c] mx-auto mt-5 mb-5" />
          <p className="text-[14px] md:text-[15px] leading-7 text-[#62554a]">
            Tell us about your celebration and your dream cake. Fill in the form below and our team will contact you on WhatsApp to confirm the design, availability and final price.
          </p>
        </div>

        <div className="mb-8 grid sm:grid-cols-3 gap-4">
          {[
            ['Choose your details', 'Occasion, flavour, size and preferred date'],
            ['Share your idea', 'Tell us your colours, theme and cake message'],
            ['We confirm with you', 'Availability, final design and price on WhatsApp'],
          ].map(([title, text], index) => (
            <div key={title} className="rounded-[8px] border border-[#dfcdb8] bg-[#fff9f0] px-5 py-5 shadow-[0_8px_28px_rgba(83,55,32,.05)]">
              <div className="mb-3 flex items-center gap-3">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-[#efe0cf] text-[#8b542d] font-semibold text-sm">{index + 1}</span>
                <h3 className="font-semibold text-[#38291f]">{title}</h3>
              </div>
              <p className="text-[13px] leading-6 text-[#6a5b4f]">{text}</p>
            </div>
          ))}
        </div>

        <div className="mb-7 overflow-hidden rounded-[12px] border border-[#decbb4] bg-[#efe2d1] shadow-[0_14px_40px_rgba(79,52,28,.08)]">
          <div className="relative h-[180px] sm:h-[220px] md:h-[260px]">
            <img src={cakeBanner} alt="Golok Cakes custom cake creations" className="absolute inset-0 h-full w-full object-cover object-center" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#fff8ee]/95 via-[#fff8ee]/72 to-transparent" />
            <div className="relative z-10 flex h-full max-w-[610px] items-center gap-4 px-5 sm:px-8 md:px-10">
              <img src={logo} alt="The Golok Cakes" className="hidden sm:block h-[120px] md:h-[150px] w-auto object-contain drop-shadow-sm" />
              <div>
                <p className="text-[10px] sm:text-[11px] font-semibold tracking-[.22em] uppercase text-[#9d744c]">Baked with love</p>
                <h3 className="mt-2 text-[27px] sm:text-[34px] md:text-[40px] leading-[1.08] text-[#34251c]" style={{ fontFamily: 'Georgia, Times New Roman, serif' }}>Your celebration, made sweeter.</h3>
                <p className="mt-3 max-w-[430px] text-[12px] sm:text-[13px] leading-6 text-[#655448]">Thoughtfully made. Beautifully designed. Always from the heart.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-[10px] border border-[#decbb4] bg-[#fffaf3] shadow-[0_18px_55px_rgba(79,52,28,.08)] overflow-hidden">
          <div className="px-6 md:px-8 py-5 border-b border-[#e7d7c4] bg-[#f3e5d4] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-full bg-[#8b542d] text-white"><CakeSlice size={21} /></span>
              <div>
                <p className="text-[11px] font-semibold tracking-[.16em] uppercase text-[#9d744c]">Custom cake enquiry</p>
                <p className="mt-1 text-sm text-[#54473d]">Complete the form and submit your request.</p>
              </div>
            </div>
            <a href={googleFormUrl} target="_blank" rel="noreferrer" className="text-[11px] font-semibold tracking-[.07em] text-[#8b542d] hover:text-[#6d3e25] whitespace-nowrap">OPEN IN GOOGLE FORMS ↗</a>
          </div>

          <div className="bg-white">
            <iframe
              title="The Golok Cakes custom cake order form"
              src={googleFormEmbedUrl}
              className="block w-full h-[3977px] border-0 bg-white"
              loading="lazy"
            >
              Loading…
            </iframe>
          </div>
        </div>

        <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-4 text-[#6a5b4f]">
          <div className="flex items-center gap-2 text-[12px]"><Check size={16} className="text-[#8b542d]" /> 100% eggless</div>
          <div className="hidden sm:block h-4 w-px bg-[#d7c3ad]" />
          <div className="flex items-center gap-2 text-[12px]"><Sparkles size={16} className="text-[#8b542d]" /> Baked with love & devotion</div>
        </div>
      </div>
    </section>
  );
}
