import React from 'react';
import { Card, CardContent } from './ui/card';
import { Heart, Leaf, Award, Users } from 'lucide-react';

const About = () => {
  const features = [
    { icon: Heart, title: 'Made with Love', description: 'Every cake and dessert is crafted with passion and dedication in our home kitchen' },
    { icon: Leaf, title: '100% Eggless', description: 'All our products are completely eggless, perfect for everyone to enjoy' },
    { icon: Award, title: 'Premium Quality', description: 'We use carefully selected ingredients for beautiful taste and quality' },
    { icon: Users, title: 'Customer First', description: 'Your celebrations, preferences and special moments are our priority' }
  ];

  return (
    <section id="about" className="py-16 md:py-24 bg-[#f8eddf] border-y border-[#eadcc8]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto mb-12 md:mb-16">
          <p className="text-[11px] tracking-[.22em] uppercase font-semibold text-[#aa7b49] mb-3">Baked with devotion</p>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold text-[#2d2118] mb-4" style={{fontFamily:'Georgia, Times New Roman, serif'}}>
            About <span className="text-[#8b542d]">Golok Cakes</span>
          </h2>
          <div className="w-20 h-[2px] bg-[#c89d6f] mx-auto mb-8"></div>

          <Card className="border border-[#eadbc7] shadow-[0_16px_45px_rgba(86,58,32,.08)] bg-[#f4e7d6] text-left">
            <CardContent className="p-6 md:p-10">
              <h3 className="text-2xl md:text-3xl font-semibold text-[#2d2118] mb-5" style={{fontFamily:'Georgia, Times New Roman, serif'}}>Our Story</h3>
              <div className="space-y-5 text-[#65584d] leading-relaxed text-[15px] md:text-[17px]">
                <p>Golok Cakes began with a simple love for baking, cooking, and creating delicious treats. My sister and I have always enjoyed watching baking videos, trying new recipes, and making cakes and sweets for our family. With our family’s love for cooking and our growing passion for baking, the idea of starting our own home bakery naturally took shape.</p>
                <p>But for us, Golok Cakes is more than just a bakery—it is a small attempt to serve Krishna and His devotees. Being Krishna conscious, we felt blessed with an opportunity to prepare fresh, pure, and lovingly made baked goods that can be offered to the Lord and then enjoyed as prasadam.</p>
                <p>We believe that food offered to Krishna not only satisfies the tongue but also brings spiritual nourishment and purification. Through Golok Cakes, our heartfelt desire is to serve devotees, spread the joy of prasadam, and make every bake with love and devotion.</p>
                <p>By the mercy of Sri Guru, Srila Prabhupada, and Sri Krishna, we are blessed to continue this journey of baking, serving, and sharing prasadam. 💛</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature) => (
            <Card key={feature.title} className="border border-[#eadbc7] shadow-[0_10px_30px_rgba(86,58,32,.06)] hover:shadow-[0_14px_38px_rgba(86,58,32,.10)] transition-all duration-300 hover:-translate-y-1 bg-[#fff9f0]">
              <CardContent className="p-6 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-[#f2e2cc] rounded-full mb-4">
                  <feature.icon className="w-8 h-8 text-[#9a653b]" />
                </div>
                <h3 className="text-lg font-semibold text-[#34271e] mb-2">{feature.title}</h3>
                <p className="text-sm leading-6 text-[#6d6054]">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
