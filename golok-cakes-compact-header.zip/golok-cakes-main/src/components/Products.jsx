import React from 'react';
import cake01 from '../assets/new-cake-01.jpeg';
import cake02 from '../assets/new-cake-05.jpeg';
import cake03 from '../assets/new-cake-07.jpeg';
import cake04 from '../assets/new-cake-08.jpeg';

const featuredCakes = [
  { name: 'Blue Vintage Tier Cake', image: cake01 },
  { name: 'Floral Birthday Cake', image: cake02 },
  { name: 'Vintage Celebration Cake', image: cake03 },
  { name: 'Heart Celebration Cake', image: cake04 },
];

export default function Products({ onNavigate }) {
  const go = () => onNavigate?.('contact');

  return (
    <section id="products" className="cream-texture py-12 md:py-16 border-b border-[#eee8de]">
      <div className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12">
        <h2 className="text-center text-[34px] md:text-[42px] font-medium text-[#111] mb-8 md:mb-10" style={{ fontFamily: 'Georgia, Times New Roman, serif' }}>
          Featured Cakes
        </h2>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {featuredCakes.map((cake) => (
            <article key={cake.name} className="group bg-white">
              <button onClick={go} className="block w-full overflow-hidden rounded-[4px] bg-[#f2eee7] border border-[#e7dfd3]">
                <div className="aspect-[1.16/1] overflow-hidden">
                  <img src={cake.image} alt={cake.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.035]" />
                </div>
              </button>
              <div className="pt-3 text-center">
                <h3 className="text-sm md:text-base text-[#1b1b1b]" style={{ fontFamily: 'Georgia, Times New Roman, serif' }}>{cake.name}</h3>
                <button onClick={go} className="mt-1.5 text-[10px] md:text-[11px] tracking-[.08em] text-[#8b542d] hover:text-[#b19a5f]">CUSTOMIZE & ORDER</button>
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-9">
          <button onClick={() => onNavigate?.('gallery')} className="border border-[#c9b979] px-7 py-3 text-[11px] font-medium tracking-[.09em] text-[#8b542d] hover:bg-[#8b542d] hover:text-white transition-colors">
            VIEW ALL CREATIONS
          </button>
        </div>
      </div>
    </section>
  );
}
