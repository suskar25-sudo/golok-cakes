import React, { useState } from 'react';
import { Menu, X, MessageCircle, CakeSlice } from 'lucide-react';
import logo from '../assets/logo.png';

const Header = ({ currentPage = 'home', onNavigate }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const goTo = (page) => {
    onNavigate?.(page);
    setIsMobileMenuOpen(false);
  };

  // Exact order requested for the main navigation.
  const navItems = [
    { label: 'HOME', id: 'home' },
    { label: 'CAKE MENU', id: 'products' },
    { label: 'GALLERY', id: 'gallery' },
    { label: 'CUSTOMER REVIEW', id: 'reviews' },
    { label: 'ABOUT US', id: 'about' },
  ];

  const whatsappLink =
    'https://wa.me/917814848093?text=Hello%20Golok%20Cakes%2C%20I%20would%20like%20to%20place%20an%20order.';

  return (
    <header className="sticky top-0 z-50 bg-[#fffdf8] shadow-[0_1px_0_rgba(184,155,105,.28)]">
      {/* Desktop utility bar only. On mobile the actions live inside the menu to keep the header compact. */}
      <div className="hidden sm:block h-8 bg-[#f3eadc] border-b border-[#ddcfb7]">
        <div className="max-w-[1440px] mx-auto h-full px-5 sm:px-8 lg:px-12 flex items-center justify-end gap-3 sm:gap-4">
          <button
            onClick={() => goTo('contact')}
            className="hidden sm:inline-flex items-center gap-2 border-r border-[#d4c3a8] pr-4 text-[12px] font-medium tracking-[.05em] text-[#65452f] hover:text-[#8b542d] transition-colors"
          >
            <CakeSlice size={16} strokeWidth={1.7} /> CUSTOMIZE CAKE
          </button>
          <a
            href={whatsappLink}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-[3px] border border-[#bda77f] bg-[#fffdf8] px-4 py-1 text-[11px] sm:text-[12px] font-medium tracking-[.05em] text-[#3d2c20] hover:bg-[#8b542d] hover:text-white hover:border-[#8b542d] transition-colors"
          >
            <MessageCircle size={15} /> WHATSAPP ORDER
          </a>
        </div>
      </div>

      <div className="relative h-[92px] sm:h-[126px] lg:h-[136px] border-b border-[#ddcfb7] bg-[#fffdf8]">
        <div className="max-w-[1440px] mx-auto h-full px-4 sm:px-8 lg:px-12 flex items-center">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden z-20 p-2 -ml-1 text-[#6f452a]"
            aria-label="Toggle menu"
            aria-expanded={isMobileMenuOpen}
          >
            {isMobileMenuOpen ? <X size={27} /> : <Menu size={27} />}
          </button>

          <button
            onClick={() => goTo('home')}
            className="absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 sm:left-8 sm:translate-x-0 sm:top-[-16px] sm:translate-y-0 lg:left-12 lg:top-[-20px] z-10"
            aria-label="Go to home"
          >
            <img
              src={logo}
              alt="The Golok Cakes"
              className="h-[88px] sm:h-[176px] lg:h-[188px] w-auto object-contain drop-shadow-[0_5px_10px_rgba(0,0,0,.05)]"
            />
          </button>

          <nav className="hidden lg:flex flex-1 items-center justify-center gap-9 xl:gap-12 pl-[230px] pr-[30px]">
            {navItems.map((item) => {
              const active = currentPage === item.id || (currentPage === 'contact' && false);
              return (
                <button
                  key={item.id}
                  onClick={() => goTo(item.id)}
                  className={`relative py-3.5 text-[15px] xl:text-[16px] font-medium tracking-[0.02em] transition-colors whitespace-nowrap ${
                    active
                      ? 'text-[#8b542d] after:absolute after:left-0 after:right-0 after:-bottom-1 after:h-[2px] after:bg-[#8b542d]'
                      : 'text-[#241b15] hover:text-[#8b542d]'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#fffdf8] border-t border-[#e7dfcf] shadow-lg">
          <nav className="px-5 py-5 flex flex-col">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => goTo(item.id)}
                className={`text-left py-3.5 border-b border-[#eee5d8] text-sm font-medium tracking-wide ${currentPage === item.id ? 'text-[#8b542d]' : 'text-[#46372d]'}`}
              >
                {item.label}
              </button>
            ))}
            <button onClick={() => goTo('contact')} className="mt-5 inline-flex items-center justify-center gap-2 border border-[#b98b65] bg-[#fff8ef] text-[#6f3f24] px-5 py-3 text-sm font-semibold tracking-wide">
              <CakeSlice size={17} /> CUSTOMIZE CAKE
            </button>
            <a href={whatsappLink} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center justify-center gap-2 bg-[#8b542d] text-white px-5 py-3 text-sm font-semibold tracking-wide">
              <MessageCircle size={17} /> WHATSAPP ORDER
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
