import React from 'react';
import { Mail, MessageCircle, Phone } from 'lucide-react';
import logo from '../assets/logo.png';

export default function Footer({ onNavigate }) {
  const year = new Date().getFullYear();
  const go = (page) => {
    onNavigate?.(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#f0e2d2] border-t border-[#dac7ad] text-[#332a22]">
      <div className="max-w-[1280px] mx-auto px-5 sm:px-8 lg:px-12 py-10 md:py-12 grid md:grid-cols-[1.2fr_.8fr_1fr] gap-9 items-start">
        <div>
          <button onClick={() => go('home')} aria-label="Go to home"><img src={logo} alt="The Golok Cakes" className="w-[170px] h-auto mb-3" /></button>
          <p className="max-w-sm text-[13px] leading-6 text-[#64584c]">Handcrafted eggless cakes and treats, baked with love for birthdays, anniversaries and every sweet celebration.</p>
        </div>
        <div>
          <h4 className="text-[12px] font-semibold tracking-[.08em] uppercase mb-4 text-[#8b542d]">Quick Links</h4>
          <div className="flex flex-col items-start gap-2.5 text-[13px]">
            <button onClick={() => go('home')}>Home</button>
            <button onClick={() => go('products')}>Cake Menu</button>
            <button onClick={() => go('gallery')}>Gallery</button>
            <button onClick={() => go('reviews')}>Customer Review</button>
            <button onClick={() => go('about')}>About Us</button>
            <button onClick={() => go('contact')}>Customize Your Cake</button>
          </div>
        </div>
        <div>
          <h4 className="text-[12px] font-semibold tracking-[.08em] uppercase mb-4 text-[#8b542d]">Get in Touch</h4>
          <div className="space-y-3 text-[13px] text-[#564a3f]">
            <a className="flex gap-3 items-center" href="tel:+917814848093"><Phone size={16}/> +91 78148 48093</a>
            <a className="flex gap-3 items-center" href="mailto:kananchhabra07@gmail.com"><Mail size={16}/> kananchhabra07@gmail.com</a>
            <a className="flex gap-3 items-center" href="https://www.instagram.com/the_golokcakes" target="_blank" rel="noreferrer"><span aria-hidden="true" className="text-[16px] leading-none">◎</span> @the_golokcakes</a>
            <a className="inline-flex mt-2 gap-2 items-center border border-[#b79e74] bg-[#fffaf2] px-4 py-2.5 text-[11px] font-semibold tracking-[.05em]" href="https://wa.me/917814848093" target="_blank" rel="noreferrer"><MessageCircle size={15}/> WHATSAPP ORDER</a>
          </div>
        </div>
      </div>
      <div className="border-t border-[#dac7ad] py-4 px-5 text-center text-[11px] text-[#786b5e]">© {year} The Golok Cakes. Made with love & devotion.</div>
    </footer>
  );
}
