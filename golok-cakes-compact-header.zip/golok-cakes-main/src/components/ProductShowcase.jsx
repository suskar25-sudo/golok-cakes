import React, { useCallback, useEffect, useRef, useState } from 'react';
import cake01 from '../assets/new-cake-01.jpeg';
import cake02 from '../assets/new-cake-02.jpeg';
import cake03 from '../assets/new-cake-03.jpeg';
import cake09 from '../assets/new-cake-09.jpeg';
import cake11 from '../assets/new-cake-11.jpeg';
import cake14 from '../assets/new-cake-14.jpeg';

const products = [
  { name: 'Custom Celebration Cakes', image: cake11 },
  { name: 'Fresh Fruit Cakes', image: cake02 },
  { name: 'Brownies', image: cake03 },
  { name: 'Cookies', image: cake09 },
  { name: 'Tier Cakes', image: cake01 },
  { name: 'Tea Cakes', image: cake14 },
];

const loopProducts = [...products, ...products];

export default function ProductShowcase({ onNavigate }) {
  const viewportRef = useRef(null);
  const firstSetRefs = useRef([]);
  const duplicateStartRef = useRef(null);
  const autoplayRef = useRef(null);
  const manualPauseUntilRef = useRef(0);
  const hoverPausedRef = useRef(false);
  const [current, setCurrent] = useState(0);

  const getLoopWidth = useCallback(() => {
    const viewport = viewportRef.current;
    const duplicateStart = duplicateStartRef.current;
    if (!viewport || !duplicateStart) return 0;
    return duplicateStart.offsetLeft;
  }, []);

  const normalizeLoop = useCallback(() => {
    const viewport = viewportRef.current;
    const loopWidth = getLoopWidth();
    if (!viewport || !loopWidth) return;

    if (viewport.scrollLeft >= loopWidth) {
      viewport.scrollLeft -= loopWidth;
    } else if (viewport.scrollLeft < 0) {
      viewport.scrollLeft += loopWidth;
    }
  }, [getLoopWidth]);

  const syncCurrentFromScroll = useCallback(() => {
    const viewport = viewportRef.current;
    const first = firstSetRefs.current[0];
    if (!viewport || !first) return;

    const track = first.parentElement;
    const gap = track ? parseFloat(getComputedStyle(track).gap || '0') : 0;
    const step = first.getBoundingClientRect().width + gap;
    if (!step) return;

    const loopWidth = getLoopWidth();
    const logicalLeft = loopWidth ? (viewport.scrollLeft % loopWidth) : viewport.scrollLeft;
    const index = Math.round(logicalLeft / step) % products.length;
    setCurrent((index + products.length) % products.length);
  }, [getLoopWidth]);

  // Continuous autoplay. It keeps moving unless the pointer is directly over a cake card
  // or the visitor has just interacted with the carousel.
  useEffect(() => {
    const viewport = viewportRef.current;
    if (!viewport) return undefined;

    autoplayRef.current = window.setInterval(() => {
      if (hoverPausedRef.current || performance.now() < manualPauseUntilRef.current) return;
      viewport.scrollLeft += 1;
      normalizeLoop();
    }, 20); // ~50px/second — clearly visible, smooth continuous movement

    return () => {
      if (autoplayRef.current) window.clearInterval(autoplayRef.current);
    };
  }, [normalizeLoop]);

  // Keep the active dot in sync without doing extra work on every animation tick.
  useEffect(() => {
    const id = window.setInterval(syncCurrentFromScroll, 180);
    return () => window.clearInterval(id);
  }, [syncCurrentFromScroll]);

  const nudge = useCallback((direction) => {
    const viewport = viewportRef.current;
    const first = firstSetRefs.current[0];
    if (!viewport || !first) return;

    const track = first.parentElement;
    const gap = track ? parseFloat(getComputedStyle(track).gap || '0') : 0;
    const step = first.getBoundingClientRect().width + gap;
    manualPauseUntilRef.current = performance.now() + 900;

    viewport.scrollBy({ left: direction * step, behavior: 'smooth' });
    window.setTimeout(() => {
      normalizeLoop();
      syncCurrentFromScroll();
    }, 650);
  }, [normalizeLoop, syncCurrentFromScroll]);

  const goTo = useCallback((index) => {
    const viewport = viewportRef.current;
    const first = firstSetRefs.current[0];
    if (!viewport || !first) return;

    const track = first.parentElement;
    const gap = track ? parseFloat(getComputedStyle(track).gap || '0') : 0;
    const step = first.getBoundingClientRect().width + gap;
    manualPauseUntilRef.current = performance.now() + 1000;
    viewport.scrollTo({ left: index * step, behavior: 'smooth' });
    setCurrent(index);
  }, []);

  return (
    <section className="sweet-showcase" aria-label="Our sweet creations">
      <div className="sweet-showcase__heading">
        <p>FRESH FROM OUR KITCHEN</p>
        <h2>Our Sweet Creations <span>✦</span></h2>
        <p className="sweet-showcase__sub">Freshly baked. Beautifully crafted. Made with love.</p>
      </div>

      <div className="sweet-showcase__carousel">
        <button
          type="button"
          className="sweet-showcase__arrow sweet-showcase__arrow--left"
          onClick={() => nudge(-1)}
          aria-label="Show previous product"
        >
          ‹
        </button>

        <div
          className="sweet-showcase__viewport"
          ref={viewportRef}
          onScroll={syncCurrentFromScroll}
          onPointerDown={() => { manualPauseUntilRef.current = performance.now() + 1400; }}
          onTouchStart={() => { manualPauseUntilRef.current = performance.now() + 1400; }}
        >
          <div className="sweet-showcase__track">
            {loopProducts.map((product, index) => (
              <button
                key={`${product.name}-${index}`}
                ref={(node) => {
                  if (index < products.length) firstSetRefs.current[index] = node;
                  if (index === products.length) duplicateStartRef.current = node;
                }}
                type="button"
                className="sweet-card"
                onMouseEnter={() => { hoverPausedRef.current = true; }}
                onMouseLeave={() => { hoverPausedRef.current = false; }}
                onFocus={() => { hoverPausedRef.current = true; }}
                onBlur={() => { hoverPausedRef.current = false; }}
                onClick={() => onNavigate?.('products')}
                aria-label={`View ${product.name}`}
                aria-hidden={index >= products.length ? 'true' : undefined}
                tabIndex={index >= products.length ? -1 : 0}
              >
                <img src={product.image} alt={product.name} />
                <div className="sweet-card__shade" />
                <div className="sweet-card__copy">
                  <span>{product.name}</span>
                  <small>VIEW COLLECTION →</small>
                </div>
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          className="sweet-showcase__arrow sweet-showcase__arrow--right"
          onClick={() => nudge(1)}
          aria-label="Show next product"
        >
          ›
        </button>
      </div>

      <div className="sweet-showcase__dots" aria-label="Carousel position">
        {products.map((product, index) => (
          <button
            key={product.name}
            type="button"
            className={index === current ? 'is-active' : ''}
            onClick={() => goTo(index)}
            aria-label={`Show ${product.name}`}
            aria-current={index === current ? 'true' : undefined}
          />
        ))}
      </div>
    </section>
  );
}
