import React, { useEffect, useState } from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Products from "./components/Products";
import ProductShowcase from "./components/ProductShowcase";
import Gallery from "./components/Gallery";
import Testimonials from "./components/Testimonials";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import { Toaster } from "./components/ui/sonner";

function App() {
  const [currentPage, setCurrentPage] = useState("home");

  const navigate = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  useEffect(() => {
    const pageTitles = {
      home: "The Golok Cakes",
      products: "Cake Menu | The Golok Cakes",
      gallery: "Gallery | The Golok Cakes",
      reviews: "Customer Reviews | The Golok Cakes",
      about: "About Us | The Golok Cakes",
      contact: "Customize Your Cake | The Golok Cakes",
    };
    document.title = pageTitles[currentPage] || "The Golok Cakes";
  }, [currentPage]);

  const renderPage = () => {
    switch (currentPage) {
      case "products":
        return <Products onNavigate={navigate} />;
      case "gallery":
        return <Gallery />;
      case "reviews":
        return <Testimonials />;
      case "about":
        return <About />;
      case "contact":
        return <Contact />;
      case "home":
      default:
        return (
          <>
            <Hero onNavigate={navigate} />
            <ProductShowcase onNavigate={navigate} />
            <Products onNavigate={navigate} />
          </>
        );
    }
  };

  return (
    <div className="App min-h-screen bg-[#fffaf2]">
      <Header currentPage={currentPage} onNavigate={navigate} />
      <main key={currentPage} className="page-enter min-h-[58vh]">
        {renderPage()}
      </main>
      <Footer onNavigate={navigate} />
      <Toaster />
    </div>
  );
}

export default App;
